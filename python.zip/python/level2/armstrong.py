n=int(input("enter number"))
temp=n
sum_=0
while n>0:
    digit=n%10
    sum_+=(digit**3)
    n//=10
if sum_==temp:
    print("armstrong")
else:
    print("it is not armstrong")
