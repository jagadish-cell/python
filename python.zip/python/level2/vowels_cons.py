#vowels&cons
s=input("enter a string").lower()
vowels="aeiou"
v=c=0
for ch in s:
    if ch.isalpha():
        if ch in vowels:
            v+=1
            print(ch, "is a vowel")
        else:
            c+=1
            print(ch, "is a consonant")

print("vowels",v)
print("consonants",c)
