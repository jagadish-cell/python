n=int(input("enter rows"))
for i in range(1,n+1):
    print("*"*(2*i-1)+" "*(n-1))
