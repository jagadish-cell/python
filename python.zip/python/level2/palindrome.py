#palindrome
n=int(input("enter a number:"))
temp=n
rev=0
while n>0:
    rev=(rev*10)+n%10
    n//=10
if rev==temp:
    print("its a palindrome")

else:
    print("its not palindrome")
    
