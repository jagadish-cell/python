#string palindrome
s=str(input("enter a string:"))
rev=s[::-1]
if s==rev:
    print("its a palindrome",rev)
else:
    print("its not a palindrome",rev)
