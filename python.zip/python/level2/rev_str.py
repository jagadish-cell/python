#string reverse using loop
'''s="hello"
rev=""
for ch in s:
    rev=ch+rev

print("rev string:",rev)'''
#slicing
s="hello"
rev=s[::-1]
print("rev of string",rev)
