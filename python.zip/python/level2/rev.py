#reverse of a number
n=int(input("enter number:"))
temp=n
rev=0
while n>0:
    digit=n%10
    rev=(rev*10)+digit
    n//=10

print("reverse of a number:",rev)
