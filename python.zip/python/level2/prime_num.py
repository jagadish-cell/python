#prime number
n=int(input("enter number:"))
if n>1:
    for i in range(2,n):
        if n%i==0:
            print("it is not a prime number")
            break
    else:
         print("it is prime ")
else:
    print("it is not prime")
