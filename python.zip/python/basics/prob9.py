#Take two numbers and swap them (without using a third variable)
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

a = a + b
b = a - b
a = a - b

print("After swapping: a =", a, "b =", b)

a,b=10,5
a,b=b,a


