#Write a program to find the square and cube of a number.
def square_of_num(x):
    x=x*x
    return(x)

def cube_of_num(y):
    y=y*y*y
    return(y)

n=int(input("enter a number"))
sq=square_of_num(n)
cb=cube_of_num(n)
print(sq,cb)
