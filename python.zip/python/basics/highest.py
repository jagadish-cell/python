marks=[80,95,98,40,50]
highest=marks[0]
for i in marks:
    if i>highest:
        highest=i

print(highest)
    
