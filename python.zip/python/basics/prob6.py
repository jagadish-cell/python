#prob6: simple interest
p=int(input("enter principal amount:"))
r=int(input("enter rate of interest amount:"))
t=int(input("enter duration in years:"))
SI=(p*r*t)/100
print("simple interest is:",SI)
