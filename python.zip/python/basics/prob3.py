#Problem 3: Largest of Three Numbers
n1=10
n2=20
n3=30
if n1>n2 & n1>n3:
    print("n1 is the largest number",n1)

elif n2>n1 & n2>n3:
    print("n2 is the largest number",n2)

else:
    print("n3 is the largest number",n3)
