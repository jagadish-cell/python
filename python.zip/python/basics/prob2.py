#Problem 2: Check Even or Odd
n=int(input("enter number:"))
if n % 2 == 0:
print("it is even number")

else:
    print("it is not even number")


3{5}1
  3
