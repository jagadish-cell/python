'''Problem 1: Area and Circumference of a Circle

Formula:

Area = π × r²

Circumference = 2 × π × r
Use π = 22/7'''

r=int(input("enter radius:"))
pi=22/7
area=pi*(r**2)
circum=2*pi*r
print("area=",area)
print("circum=",round(circum,4))
