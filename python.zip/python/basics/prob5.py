c=float(input("enter temp in celcious:"))
f=(c*(9/5))+32
print("farighenheit:",f)
