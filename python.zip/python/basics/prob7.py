#Check if a number is positive, negative, or zero.
t=int(input("enter test cases:"))
for _ in range(t):
    n=int(input("enter a number:"))
    if n>0:
        print("it is positive number")
    elif n<0:
        print("it is negative number")
    else:
        print("it is 0")

