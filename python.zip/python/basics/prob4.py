#Problem 4: Sum of First N Natural Numbers
n=int(input("enter n value:"))
sum_n=0
for i in range(1,n+1):
    sum_n+=i
    
print("sum of n natural numbers:",sum_n)
